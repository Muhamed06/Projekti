const username = document.getElementById('username');
const email = document.getElementById('email');

if (name.value === '' || name.value == null){

	message.push('Name is required')
}



